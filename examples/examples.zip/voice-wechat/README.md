# 微信小程序实时语音对话

这是一个从Web版本迁移到微信小程序的实时语音对话项目。基于原有的React Web应用(@app.tsx和@realtime-manager.ts)重新实现。

## 功能特性

从原Web版本迁移的核心功能:
- 实时语音对话连接管理(连接、断开、打断)
- 麦克风控制(静音/取消静音)
- 语音设备权限检查
- 事件监听和处理
- 语音合成支持

## 技术迁移方案

### Web版本到小程序版本的对应关系

Web版本 -> 小程序版本:
- WebRTC API -> 微信实时语音API(wx.createWebAudioContext())
- React组件 -> 小程序组件
- Antd组件 -> 微信原生组件
- React Hooks -> 小程序页面生命周期
- RealtimeManager类 -> 小程序版RealtimeManager工具类

### 项目结构 
realtime-wechat/
├── pages/ # 页面文件
│ └── index/ # 主页面
│ ├── index.js # 页面逻辑
│ ├── index.wxml # 页面结构
│ ├── index.wxss # 页面样式
│ └── index.json # 页面配置
├── utils/ # 工具类
│ └── realtime-manager.js # 实时通信管理
├── app.js # 应用入口
├── app.json # 应用配置
├── app.wxss # 应用样式
└── project.config.json # 项目配置

## 核心功能实现

### 1. 实时通信管理器

从原Web版本的RealtimeManager类迁移:
javascript
// utils/realtime-manager.js
class RealtimeManager {
constructor(config) {
this.audioEnabled = true;
this.recorderManager = wx.getRecorderManager();
this.audioContext = wx.createWebAudioContext();
}
async toggleMicrophone() {
this.audioEnabled = !this.audioEnabled;
if (this.audioEnabled) {
this.recorderManager.start();
} else {
this.recorderManager.stop();
}
}
async connect() {
// 实现连接逻辑
}

async disconnect() {
// 实现断开逻辑
}
async interrupt() {
// 实现打断逻辑
}
}

### 2. 页面实现

从原Web版本的App.tsx迁移:

// pages/index/index.js
Page({
data: {
isConnected: false,
audioEnabled: true
},
onLoad() {
this.initClient();
},
async initClient() {
try {
const auth = await wx.authorize({scope: 'scope.record'});
this.realtimeManager = new RealtimeManager({
// 配置参数
});
} catch (error) {
wx.showToast({
title: '需要麦克风权限',
icon: 'none'
});
}
},
},
handleConnect() {
this.realtimeManager.connect();
},
handleDisconnect() {
this.realtimeManager.disconnect();
},
handleInterrupt() {
this.realtimeManager.interrupt();
},
toggleMicrophone() {
this.realtimeManager.toggleMicrophone();
this.setData({
audioEnabled: this.realtimeManager.audioEnabled
});
}
});

## 部署和运行

1. 环境准备
- 安装[微信开发者工具](https://developers.weixin.qq.com/miniprogram/dev/devtools/download.html)
- 准备小程序AppID

2. 项目配置
json:README.md
{
"appid": "你的小程序AppID",
"projectname": "realtime-wechat"
}

3. 开发环境运行
- 使用微信开发者工具打开项目
- 填入AppID
- 点击编译运行

4. 生产环境部署
- 在微信开发者工具中点击"上传"
- 在小程序管理后台提交审核
- 审核通过后发布

## 注意事项

1. API限制
- 小程序的音频API与Web版本有较大差异
- 需要适配微信环境的特殊限制

2. 性能优化
- 控制音频数据大小
- 优化重连逻辑
- 减少不必要的状态更新

3. 用户体验
- 添加加载状态提示
- 完善错误提示
- 优化移动端触摸体验

4. 安全性
- 注意API调用频率限制
- 做好异常处理
- 保护用户隐私数据

## 待优化项

1. 技术层面
- 添加断网重连机制
- 增加音频质量监控
- 优化性能和内存占用

2. 用户体验
- 增加更多交互反馈
- 优化界面布局
- 添加更多错误处理和提示

3. 功能扩展
- 支持更多音频格式
- 添加音量调节
- 支持后台运行

## 版本历史

- v1.0.0 (开发中)
  - 基础实时对话功能
  - 麦克风控制
  - 连接管理

## 许可证

[MIT License](LICENSE)

