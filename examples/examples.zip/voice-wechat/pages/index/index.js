// index.js
const RealtimeManager = require('../../utils/realtime-manager.js');

const CONFIG = {
  accessToken: 'pat_Pcvuj7NOFT4EfHSJMjqZYDOmbB6TxFSSsr1BHqrUCI7inqWbIxz7vYrRnJEcjpex',
  botId: '7447765883952398386',
  voiceId: '7426725529589596187',
  baseURL: 'https://api.coze.cn'
};

Page({
  data: {
    isConnected: false,
    isMicrophoneOn: true,
    isLoading: false
  },

  realtimeManager: null,

  onLoad: function() {
    this.checkWebRTC();
  },

  checkWebRTC: function() {
    wx.getSystemInfo({
      success: (res) => {
        if (!res.platform) {
          wx.showToast({
            title: '设备不支持实时语音',
            icon: 'none'
          });
          return;
        }
        this.initClient();
      },
      fail: () => {
        wx.showToast({
          title: '获取设备信息失败',
          icon: 'none'
        });
      }
    });
  },

  initClient: function() {
    wx.authorize({
      scope: 'scope.record',
      success: () => {
        if (!this.realtimeManager) {
          this.realtimeManager = new RealtimeManager(CONFIG);
          this.realtimeManager.addEventListeners(this.handleAllMessage);
        }
      },
      fail: () => {
        wx.showToast({
          title: '需要麦克风权限',
          icon: 'none'
        });
      }
    });
  },

  handleConnect: function() {
    if (!this.realtimeManager) {
      this.initClient();
      return;
    }

    this.setData({ isLoading: true });
    this.realtimeManager.connect()
      .then(() => {
        this.setData({ 
          isConnected: true,
          isLoading: false 
        });
        wx.showToast({
          title: '已连接，请开始对话',
          icon: 'success'
        });
      })
      .catch((error) => {
        console.error('连接错误:', error);
        this.setData({ isLoading: false });
        wx.showToast({
          title: '连接失败',
          icon: 'error'
        });
      });
  },

  handleDisconnect: function() {
    this.realtimeManager?.disconnect()
      .then(() => {
        this.setData({ isConnected: false });
        wx.showToast({
          title: '已断开',
          icon: 'success'
        });
      })
      .catch((error) => {
        console.error('断开连接失败:', error);
        wx.showToast({
          title: '断开失败',
          icon: 'error'
        });
      });
  },

  handleInterrupt: function() {
    this.realtimeManager?.interrupt()
      .catch((error) => {
        console.error('打断失败:', error);
        wx.showToast({
          title: '打断失败',
          icon: 'error'
        });
      });
  },

  toggleMicrophone: function() {
    this.realtimeManager?.toggleMicrophone()
      .then(() => {
        this.setData({
          isMicrophoneOn: this.realtimeManager?.audioEnabled
        });
      })
      .catch((error) => {
        console.error('麦克风操作失败:', error);
        wx.showToast({
          title: '操作失败',
          icon: 'error'
        });
      });
  },

  handleAllMessage: function(eventName, event) {
    console.log('event:', eventName, event);
    switch (eventName) {
      case 'connect':
        wx.showToast({
          title: '连接成功',
          icon: 'success'
        });
        break;
      case 'disconnect':
        wx.showToast({
          title: '连接已断开',
          icon: 'none'
        });
        break;
      case 'error':
        wx.showToast({
          title: '发生错误',
          icon: 'error'
        });
        break;
      default:
        break;
    }
  },

  onUnload: function() {
    if (this.realtimeManager) {
      this.realtimeManager.removeEventListeners(this.handleAllMessage);
      this.handleDisconnect();
    }
  },

  handleTextChat: function() {
    wx.showToast({
      title: '文字对话功能开发中',
      icon: 'none'
    });
  }
});
