import { RealtimeManager } from '../../utils/realtime-manager';

// 配置信息
const CONFIG = {
  accessToken: 'pat_Pcvuj7NOFT4EfHSJMjqZYDOmbB6TxFSSsr1BHqrUCI7inqWbIxz7vYrRnJEcjpex',
  botId: '7447765883952398386',
  voiceId: '7426725529589596187',
  baseURL: 'https://api.coze.cn'
};

Page({
  data: {
    isConnected: false,
    isMicrophoneOn: true,
    isLoading: false
  },

  realtimeManager: null as RealtimeManager | null,

  onLoad() {
    this.checkWebRTC();
  },

  // 检查WebRTC支持
  async checkWebRTC() {
    try {
      const res = await wx.getSystemInfo();
      if (!res.platform) {
        wx.showToast({
          title: '设备不支持实时语音',
          icon: 'none'
        });
        return;
      }
      this.initClient();
    } catch (error) {
      wx.showToast({
        title: '获取设备信息失败',
        icon: 'none'
      });
    }
  },

  // 初始化客户端
  async initClient() {
    try {
      // 检查麦克风权限
      const auth = await wx.authorize({ scope: 'scope.record' });
      
      // 初始化实时管理器
      if (!this.realtimeManager) {
        this.realtimeManager = new RealtimeManager(CONFIG);
        this.realtimeManager.addEventListeners(this.handleAllMessage);
      }

      // 检查音频设备
      const isMobile = /iPhone|iPad|iPod|Android/i.test(wx.getSystemInfoSync().platform);
      if (isMobile) {
        wx.showToast({
          title: '请允许麦克风访问权限',
          icon: 'none'
        });
      }

    } catch (error) {
      console.error('初始化失败:', error);
      wx.showToast({
        title: '需要麦克风权限',
        icon: 'none'
      });
    }
  },

  // 连接
  async handleConnect() {
    if (!this.realtimeManager) {
      await this.initClient();
    }

    this.setData({ isLoading: true });
    try {
      await this.realtimeManager?.connect();
      this.setData({ 
        isConnected: true,
        isLoading: false 
      });
      wx.showToast({
        title: '已连接，请开始对话',
        icon: 'success'
      });
    } catch (error) {
      console.error('连接错误:', error);
      this.setData({ isLoading: false });
      wx.showToast({
        title: '连接失败',
        icon: 'error'
      });
    }
  },

  // 断开连接
  async handleDisconnect() {
    try {
      await this.realtimeManager?.disconnect();
      this.setData({ isConnected: false });
      wx.showToast({
        title: '已断开',
        icon: 'success'
      });
    } catch (error) {
      console.error('断开连接失败:', error);
      wx.showToast({
        title: '断开失败',
        icon: 'error'
      });
    }
  },

  // 打断对话
  async handleInterrupt() {
    try {
      await this.realtimeManager?.interrupt();
    } catch (error) {
      console.error('打断失败:', error);
      wx.showToast({
        title: '打断失败',
        icon: 'error'
      });
    }
  },

  // 切换麦克风
  async toggleMicrophone() {
    try {
      await this.realtimeManager?.toggleMicrophone();
      this.setData({
        isMicrophoneOn: this.realtimeManager?.audioEnabled
      });
    } catch (error) {
      console.error('麦克风操作失败:', error);
      wx.showToast({
        title: '操作失败',
        icon: 'error'
      });
    }
  },

  // 处理所有消息
  handleAllMessage(eventName: string, event: any) {
    console.log('event:', eventName, event);
    // 根据不同的事件类型处理
    switch (eventName) {
      case 'connect':
        wx.showToast({
          title: '连接成功',
          icon: 'success'
        });
        break;
      case 'disconnect':
        wx.showToast({
          title: '连接已断开',
          icon: 'none'
        });
        break;
      case 'error':
        wx.showToast({
          title: '发生错误',
          icon: 'error'
        });
        break;
      default:
        break;
    }
  },

  // 页面卸载
  onUnload() {
    if (this.realtimeManager) {
      this.realtimeManager.removeEventListeners(this.handleAllMessage);
      this.handleDisconnect();
    }
  },

  // 跳转到文字对话
  handleTextChat() {
    wx.showToast({
      title: '文字对话功能开发中',
      icon: 'none'
    });
  }
}); 