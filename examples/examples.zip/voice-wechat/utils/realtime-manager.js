//const { RealtimeClient, EventNames, RealtimeAPIError } = require('node_modules/@coze/realtime-api');
const { RealtimeClient, EventNames, RealtimeAPIError } = require('@coze/realtime-api');
//import { RealtimeClient, EventNames, RealtimeAPIError } from "@coze/realtime-api";


function RealtimeManager(config) {
  // 初始化录音管理器
  this.recorderManager = wx.getRecorderManager();
  this.innerAudioContext = wx.createInnerAudioContext();
  this.audioEnabled = true;

  // 初始化实时客户端
  this.client = new RealtimeClient({
    ...config,
    allowPersonalAccessTokenInBrowser: true,
    audioMutedDefault: false,
    suppressStationaryNoise: true,
    suppressNonStationaryNoise: true,
    connectorId: '1024'
  });

  // 设置录音相关监听
  this.setupRecorderListeners();
}

RealtimeManager.prototype = {
  setupRecorderListeners: function() {
    this.recorderManager.onStart(() => {
      console.log('录音开始');
    });

    this.recorderManager.onStop((res) => {
      console.log('录音结束', res);
    });

    this.recorderManager.onError((err) => {
      console.error('录音错误', err);
    });
  },

  connect: function() {
    return this.client.connect()
      .then(() => {
        this.startRecording();
      })
      .catch((error) => {
        if (error instanceof RealtimeAPIError) {
          throw new Error(`连接失败: ${error.message}`);
        }
        throw error;
      });
  },

  disconnect: function() {
    return this.client.disconnect()
      .then(() => {
        this.stopRecording();
      })
      .catch((error) => {
        console.error('断开连接失败:', error);
        throw error;
      });
  },

  interrupt: function() {
    return this.client.interrupt()
      .catch((error) => {
        console.error('打断失败:', error);
        throw error;
      });
  },

  toggleMicrophone: function() {
    this.audioEnabled = !this.audioEnabled;
    return this.client.setAudioEnable(this.audioEnabled)
      .then(() => {
        if (this.audioEnabled) {
          this.startRecording();
        } else {
          this.stopRecording();
        }
      });
  },

  startRecording: function() {
    this.recorderManager.start({
      duration: 60000,
      sampleRate: 16000,
      numberOfChannels: 1,
      encodeBitRate: 48000,
      format: 'PCM'
    });
  },

  stopRecording: function() {
    this.recorderManager.stop();
  },

  addEventListeners: function(callback) {
    this.client.on(EventNames.ALL, callback);
  },

  removeEventListeners: function(callback) {
    this.client.off(EventNames.ALL, callback);
  }
};

module.exports = RealtimeManager; 