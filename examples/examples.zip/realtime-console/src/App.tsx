import React from 'react';
import RealtimeConsole from './pages/main';

const App: React.FC = () => (
  <RealtimeConsole />
);

export default App;
